<?php
  
 class totospeler {
     
   public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
  
   
      public function getNaam(){
       return $this->naam;
   }
   
      public function setNaam(){
       return $this->naam;
   }
 }