<?php


 
 class totospelerploeg {
     
     public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
   
 };