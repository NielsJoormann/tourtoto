<?php


 

class etapperegel {
   public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
   public function getPositie(){
       return $this->positie;
   }
   
    public function setPositie(){
       return $this->positie;
   }
   
      public function getTijd(){
       return $this->tijd;
   }
   
      public function setTijd(){
       return $this->tijd;
   }
    
}