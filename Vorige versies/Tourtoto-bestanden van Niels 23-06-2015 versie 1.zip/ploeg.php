<?php


 
 class ploeg {
     
          
   public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
   public function getCode(){
       return $this->code;
   }
   
    public function setCode(){
       return $this->code;
   }
   
      public function getNaam(){
       return $this->naam;
   }
   
      public function setNaam(){
       return $this->naam;
   }
     
 };
 

