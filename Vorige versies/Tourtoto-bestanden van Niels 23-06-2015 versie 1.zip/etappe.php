<?php 

 
  class etappe{
      
   public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
   public function getNaam(){
       return $this->naam;
   }
   
    public function setNaam(){
       return $this->naam;
   }
   
      public function getAfstand(){
       return $this->afstand;
   }
   
      public function setAfstand(){
       return $this->afstand;
   }
 }
