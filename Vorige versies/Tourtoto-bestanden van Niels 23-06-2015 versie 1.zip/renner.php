<?php
 

 
class renner {
    
    public $id;
    public $voornaam;
    public $achternaam;
    
    public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
   public function getVoornaam(){
       return $this->voornaam;
   }
   
    public function setVoornaam(){
       return $this->voornaam;
   }
   
      public function getAchternaam(){
       return $this->achternaam;
   }
   
      public function setAchternaam(){
       return $this->achternaam;
   }
    
};