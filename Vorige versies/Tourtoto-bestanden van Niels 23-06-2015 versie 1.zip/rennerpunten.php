<?php

class rennerpunten {
    public function getId(){
       return $this->id;
   }
   
   public function setId(){
       return $this->id;
   }
   
   public function getPunten(){
       return $this->punten;
   }
   
    public function setPunten(){
       return $this->punten;
   }
};

