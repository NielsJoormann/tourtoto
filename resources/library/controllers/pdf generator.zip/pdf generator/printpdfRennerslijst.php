<?php

 require_once 'pdfRennerslijst.php';
 
 $pdfRennerslijst = new pdfRennerslijst;
 $pdfRennerslijst->createNewPdf();
 ?>