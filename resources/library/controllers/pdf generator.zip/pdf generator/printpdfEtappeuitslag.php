<?php

 require_once 'pdfEtappeuitslag.php';
 
 $pdfEtappeuitslag = new pdfEtappeuitslag();
 $pdfEtappeuitslag->createNewPdf();
 ?>