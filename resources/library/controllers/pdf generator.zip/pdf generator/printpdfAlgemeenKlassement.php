<?php

 require_once 'pdfAlgemeenKlassement.php';
 
 $pdfAlgemeenKlassement = new pdfAlgemeenKlassement();
 $pdfAlgemeenKlassement->createNewPdf();
 ?>